package com.kantinjujur.app

import android.os.Bundle
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton

 data class Product(val name: String, val category: String, val price: Int, val emoji: String, val description: String)

class MainActivity : AppCompatActivity() {
    private val products = listOf(
        Product("Aqua 600 ml", "Minuman", 3000, "💧", "Air mineral untuk menemani aktivitasmu di sekolah."),
        Product("Le Minerale", "Minuman", 3000, "🧴", "Air mineral segar dalam kemasan praktis."),
        Product("Teh Botol", "Minuman", 4000, "🧃", "Minuman teh dengan rasa manis yang menyegarkan."),
        Product("Sari Roti", "Minuman", 3000, "🥤", "Minuman kemasan yang cocok dinikmati saat istirahat."),
        Product("Jus Buah", "Minuman", 5000, "🧃", "Minuman rasa buah yang menyegarkan."),
        Product("Kopi Susu", "Minuman", 5000, "🥛", "Minuman kopi susu siap minum."),
        Product("Beng-Beng", "Jajanan", 2000, "🍫", "Camilan cokelat renyah untuk teman belajar."),
        Product("Malkist", "Jajanan", 2000, "🍪", "Biskuit renyah yang pas untuk camilan."),
        Product("Biskuit Cokelat", "Jajanan", 3000, "🍪", "Biskuit dengan lapisan rasa cokelat."),
        Product("Wafer Cokelat", "Jajanan", 2000, "🍫", "Wafer berlapis dengan rasa cokelat."),
        Product("Roti Cokelat", "Jajanan", 3000, "🥐", "Roti lembut dengan isian cokelat."),
        Product("Pop Mie", "Jajanan", 6000, "🍜", "Mi instan cup praktis untuk mengganjal lapar.")
    )
    private var selectedCategory = "Semua"
    private var cartCount = 0
    private lateinit var adapter: ProductAdapter
    private lateinit var cartSummary: TextView
    private lateinit var searchInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showCatalog()
    }

    private fun showCatalog() {
        setContentView(R.layout.activity_main)
        cartSummary = findViewById(R.id.cartSummary)
        searchInput = findViewById(R.id.searchInput)
        val recycler = findViewById<RecyclerView>(R.id.productRecycler)
        recycler.layoutManager = GridLayoutManager(this, 2)
        adapter = ProductAdapter(this, products) { product -> showDetail(product) }
        recycler.adapter = adapter
        findViewById<Button>(R.id.allButton).setOnClickListener { selectedCategory = "Semua"; filterProducts() }
        findViewById<Button>(R.id.snackButton).setOnClickListener { selectedCategory = "Jajanan"; filterProducts() }
        findViewById<Button>(R.id.drinkButton).setOnClickListener { selectedCategory = "Minuman"; filterProducts() }
        searchInput.addTextChangedListener(SimpleTextWatcher { filterProducts() })
        updateCartSummary()
    }

    private fun filterProducts() {
        val query = searchInput.text.toString().trim()
        val filtered = products.filter {
            (selectedCategory == "Semua" || it.category == selectedCategory) && it.name.contains(query, true)
        }
        adapter.update(filtered)
    }

    private fun showDetail(product: Product) {
        setContentView(R.layout.activity_detail)
        var quantity = 1
        findViewById<TextView>(R.id.backButton).setOnClickListener { showCatalog() }
        findViewById<TextView>(R.id.detailEmoji).text = product.emoji
        findViewById<TextView>(R.id.detailCategory).text = product.category
        findViewById<TextView>(R.id.detailName).text = product.name
        findViewById<TextView>(R.id.detailPrice).text = rupiah(product.price)
        findViewById<TextView>(R.id.detailDescription).text = product.description
        val quantityText = findViewById<TextView>(R.id.quantityText)
        findViewById<Button>(R.id.minusButton).setOnClickListener { if (quantity > 1) quantity--; quantityText.text = quantity.toString() }
        findViewById<Button>(R.id.plusButton).setOnClickListener { quantity++; quantityText.text = quantity.toString() }
        findViewById<TextView>(R.id.favoriteButton).setOnClickListener { Toast.makeText(this, "Produk ditandai favorit", Toast.LENGTH_SHORT).show() }
        findViewById<Button>(R.id.addToCartButton).setOnClickListener {
            cartCount += quantity
            Toast.makeText(this, "$quantity ${product.name} ditambahkan ke keranjang", Toast.LENGTH_SHORT).show()
            showCatalog()
        }
    }

    private fun updateCartSummary() { cartSummary.text = "Keranjang: $cartCount produk" }
    private fun rupiah(value: Int) = "Rp" + String.format("%,d", value).replace(',', '.')

    private inner class ProductAdapter(
        private val context: Context,
        private var items: List<Product>,
        private val onClick: (Product) -> Unit
    ) : RecyclerView.Adapter<ProductAdapter.ProductHolder>() {
        inner class ProductHolder(view: View) : RecyclerView.ViewHolder(view) {
            val emoji: TextView = view.findViewById(R.id.productEmoji)
            val category: TextView = view.findViewById(R.id.productCategory)
            val name: TextView = view.findViewById(R.id.productName)
            val price: TextView = view.findViewById(R.id.productPrice)
            val button: Button = view.findViewById(R.id.detailButton)
        }
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = ProductHolder(LayoutInflater.from(context).inflate(R.layout.item_product, parent, false))
        override fun getItemCount() = items.size
        override fun onBindViewHolder(holder: ProductHolder, position: Int) {
            val product = items[position]
            holder.emoji.text = product.emoji
            holder.category.text = product.category
            holder.name.text = product.name
            holder.price.text = rupiah(product.price)
            holder.button.setOnClickListener { onClick(product) }
            holder.itemView.setOnClickListener { onClick(product) }
        }
        fun update(newItems: List<Product>) { items = newItems; notifyDataSetChanged() }
    }
}
